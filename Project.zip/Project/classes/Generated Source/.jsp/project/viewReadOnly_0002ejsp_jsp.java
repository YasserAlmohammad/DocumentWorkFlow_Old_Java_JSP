import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;
import java.sql.*;
import java.util.StringTokenizer;

public class viewReadOnly_0002ejsp_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  static {
    _jspx_includes = new java.util.Vector(1);
    _jspx_includes.add("/ConnectInclude.jsp");
  }

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      project.Connect connector = null;
      synchronized (session) {
        connector = (project.Connect) pageContext.getAttribute("connector", PageContext.SESSION_SCOPE);
        if (connector == null){
          try {
            connector = (project.Connect) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.Connect");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.Connect", exc);
          }
          pageContext.setAttribute("connector", connector, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n");
      project.UserInfo userInfo = null;
      synchronized (application) {
        userInfo = (project.UserInfo) pageContext.getAttribute("userInfo", PageContext.APPLICATION_SCOPE);
        if (userInfo == null){
          try {
            userInfo = (project.UserInfo) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.UserInfo");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.UserInfo", exc);
          }
          pageContext.setAttribute("userInfo", userInfo, PageContext.APPLICATION_SCOPE);
        }
      }
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n\r\n");
      out.write("<head>\r\n\r\n");
      out.write("<meta name=\"GENERATOR\" content=\"Microsoft FrontPage 5.0\">\r\n");
      out.write("<meta name=\"ProgId\" content=\"FrontPage.Editor.Document\">\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1256\">\r\n\r\n");
      out.write("<title>reasd only view");
      out.write("</title>\r\n");
      out.write("</head>\r\n\r\n");
      out.write("<body bgcolor=\"#eeeeee\">\r\n");
      out.write("<p align=\"center\">\r\n");
      out.write("<a href=\"inbox.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>inbox");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"outbox.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>outbox");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"sendPageGenerator.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>send doc");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"reporting.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>reporting");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"changeUserPass.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>changePassword");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"helpFiles/help.htm\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>help&amp;support");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>");
      out.write("</p>\r\n  ");
 String doc_ids= request.getParameter("doc_ids");
     String content="",doc_serial="";
     Timestamp doc_date=null,arrive_date=null;
     String num_on_doc="",date_on_doc="";
    try{
    //we wrapped document identifiers in the request parameters
     StringTokenizer tokens=new StringTokenizer(doc_ids);
     if(tokens.hasMoreElements())
        doc_serial=tokens.nextToken("*"); // * was the separator between date and serial: date may has spaces
     if(tokens.hasMoreElements())
        doc_date=new Timestamp(Long.valueOf(tokens.nextToken("*")).longValue());
    if(tokens.hasMoreElements())
        arrive_date=new Timestamp(Long.valueOf(tokens.nextToken("*")).longValue());
     ResultSet r=connector.executeQuery("SELECT date,content,num_on_doc,date_on_doc FROM document WHERE serial="+doc_serial);

     while(r.next()){
      Timestamp d=r.getTimestamp("date");
      //check date match in day,month,year
      if((d.getYear()==doc_date.getYear())&&(d.getMonth()==doc_date.getMonth())&&(d.getDay()==doc_date.getDay())){
        content=r.getString("content");
        num_on_doc=r.getString("num_on_doc");
        date_on_doc=r.getString("date_on_doc");
      }
     }
      out.write("\r\n\r\n  ");
      out.write("<font color=\"800000\">document numeber:");
      out.print(num_on_doc);
      out.write(" originated at:");
      out.print(date_on_doc);
      out.write("</font>\r\n  ");
      out.write("<textarea rows=\"20\" name=\"content\" cols=\"100\">");
      out.print( content );
      out.write("</textarea>");
      out.write("</p>\r\n  ");

  }
  catch(SQLException e){
    
      out.write(" ERROR, you can't view this page ");

  }

      out.write("\r\n");
      out.write("<p align=\"right\">");
      out.write("<a href=\"homepage.jsp\">");
      out.write("<img border=\"0\" src=\"images/60.jpg\" width=\"72\" height=\"29\">");
      out.write("</a>");
      out.write("</p>\r\n");
      out.write("<form method=\"POST\" action=\"SignOut.jsp\">\r\n  ");
      out.write("<p>\r\n  ");
      out.write("<input type=\"submit\" value=\"sign out\" name=\"signout\">");
      out.write("</p>\r\n");
      out.write("</form>\r\n");
      out.write("</body>\r\n");
      out.write("</html>");
    } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }
}
