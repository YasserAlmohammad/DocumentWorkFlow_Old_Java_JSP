import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;
import java.sql.*;
import java.util.StringTokenizer;

public class INBOX_0002eJSP_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  static {
    _jspx_includes = new java.util.Vector(1);
    _jspx_includes.add("/ConnectInclude.jsp");
  }

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=windows-1256");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      project.Connect connector = null;
      synchronized (session) {
        connector = (project.Connect) pageContext.getAttribute("connector", PageContext.SESSION_SCOPE);
        if (connector == null){
          try {
            connector = (project.Connect) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.Connect");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.Connect", exc);
          }
          pageContext.setAttribute("connector", connector, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n");
      project.UserInfo userInfo = null;
      synchronized (application) {
        userInfo = (project.UserInfo) pageContext.getAttribute("userInfo", PageContext.APPLICATION_SCOPE);
        if (userInfo == null){
          try {
            userInfo = (project.UserInfo) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.UserInfo");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.UserInfo", exc);
          }
          pageContext.setAttribute("userInfo", userInfo, PageContext.APPLICATION_SCOPE);
        }
      }
      out.write("\r\n");
      out.write("\r\n\r\n");
      out.write("<html>\r\n\r\n");
      out.write("<head>\r\n\r\n");
      out.write("<meta name=\"GENERATOR\" content=\"Microsoft FrontPage 5.0\">\r\n");
      out.write("<meta name=\"ProgId\" content=\"FrontPage.Editor.Document\">\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1256\">\r\n\r\n");
      out.write("<title>inbox");
      out.write("</title>\r\n");
      out.write("</head>\r\n\r\n");
      out.write("<body bgcolor=\"#eeeeee\"  link=\"#200000\"  Vlink=\"#0000FF\">\r\n\r\n");
 if(userInfo.getPos_id()<0){  //security matter: if you are not signed in you can't see this page
      
      out.write(" ");
      if (true) {
        pageContext.forward("error.htm");
        return;
      }
      out.write("\r\n ");
}

      out.write("\r\n\r\n");
      out.write("<p align=\"center\">\r\n");
      out.write("<a href=\"inbox.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>inbox");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"outbox.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>outbox");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"sendPageGenerator.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>send doc");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"reporting.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>reporting");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"changeUserPass.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>changePassword");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"helpFiles/help.htm\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>help&amp;support");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>");
      out.write("</p>\r\n");
      out.write("<h1 align=\"center\">");
      out.write("<font color=\"#800000\" size=\"5\">");
      out.write("<i>Inbox");
      out.write("</i>");
      out.write("</font>");
      out.write("</h1>\r\n");
      out.write("<!-- newly recieved messages -->\r\n");
      out.write("<br>\r\n  ");
      out.write("<font color=\"#800000\" size=\"4\">newly received&nbsp; message:");
      out.write("</font>\r\n  ");
      out.write("<br>\r\n\r\n  ");
      out.write("<!-- ***************************************************************-->\r\n  ");
 ResultSet new_links=connector.executeQuery("SELECT doc_serial,subject,doc_date,arrive_date,visited FROM inbox WHERE belongs_to_pos="+ userInfo.getPos_id()+" AND visited='no'");
     String doc_ids="",doc_serial="",visited="",subj="";
     Timestamp doc_date=null,arrive_date=null;
     while(new_links.next()){
        doc_serial=new_links.getString("doc_serial");
        subj=new_links.getString("subject");
        doc_date=new_links.getTimestamp("doc_date");
        arrive_date=new_links.getTimestamp("arrive_date");
        visited=new_links.getString("visited");
        doc_ids=doc_serial+"*"+doc_date.getTime()+"*"+arrive_date.getTime();
      out.write("\r\n\r\n        ");
      out.write("<!-- we pass ids throught request -->\r\n        ");
      out.write("<img border=\"0\" src=\"images/11.gif\" width=\"20\" height=\"20\">&nbsp;\r\n        ");
      out.write("<a href=\"acceptance.jsp?doc_ids=");
      out.print( doc_ids );
      out.write("\">");
      out.write("<b>message from ");
      out.print( subj );
      out.write(" at ");
      out.print( doc_date );
      out.write("</b> ");
      out.write("</a>\r\n        ");
      out.write("<br>\r\n     ");
 } 
      out.write("\r\n");
      out.write("<br>\r\n\r\n");
      out.write("<br>\r\n");
      out.write("<!-- history trash -->\r\n");
      out.write("<form method=\"POST\" action=\"deleteVisitedLinks.jsp\">\r\n  ");
      out.write("<p>\r\n  ");
      out.write("<font color=\"#800000\" size=\"4\">visited messages(Read only): ");
      out.write("</font>");
      out.write("</p>\r\n     ");
 ResultSet visited_links=connector.executeQuery("SELECT doc_serial,subject,doc_date,arrive_date,visited FROM inbox WHERE belongs_to_pos="+ userInfo.getPos_id()+" AND visited='yes'");
     while(visited_links.next()){
        doc_serial=visited_links.getString("doc_serial");
        subj=visited_links.getString("subject");
        doc_date=visited_links.getTimestamp("doc_date");
        arrive_date=visited_links.getTimestamp("arrive_date");
        visited=visited_links.getString("visited");
        doc_ids=doc_serial+"*"+doc_date.getTime()+"*"+arrive_date.getTime();
      out.write("\r\n        ");
      out.write("<img border=\"0\" src=\"images/11.gif\" width=\"20\" height=\"20\">&nbsp;\r\n        ");
      out.write("<a href=\"viewReadOnly.jsp?doc_ids=");
      out.print( doc_ids );
      out.write("\">");
      out.write("<b>message from ");
      out.print( subj );
      out.write(" at ");
      out.print( doc_date );
      out.write("</b> ");
      out.write("</a>");
      out.write("<br>\r\n   ");
  } 
      out.write("\r\n  ");
      out.write("<p>");
      out.write("<input type=\"submit\" value=\"delete visted links\" name=\"emptytrash\">");
      out.write("</p>\r\n");
      out.write("</form>\r\n");
      out.write("<p>&nbsp;");
      out.write("</p>\r\n");
      out.write("<p align=\"right\">");
      out.write("<a href=\"homepage.jsp\">");
      out.write("<img border=\"0\" src=\"images/60.gif\" width=\"72\" height=\"29\">");
      out.write("</a>");
      out.write("</p>\r\n");
      out.write("<form method=\"POST\" action=\"SignOut.jsp\">\r\n  ");
      out.write("<p>\r\n  ");
      out.write("<input type=\"submit\" value=\"sign out\" name=\"signout\">");
      out.write("</p>\r\n");
      out.write("</form>\r\n\r\n");
      out.write("</body>\r\n\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }
}
