import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;
import java.sql.*;
import java.util.StringTokenizer;
import java.lang.String;

public class findRecieved_0002ejsp_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  static {
    _jspx_includes = new java.util.Vector(1);
    _jspx_includes.add("/ConnectInclude.jsp");
  }

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=windows-1252");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      project.Connect connector = null;
      synchronized (session) {
        connector = (project.Connect) pageContext.getAttribute("connector", PageContext.SESSION_SCOPE);
        if (connector == null){
          try {
            connector = (project.Connect) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.Connect");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.Connect", exc);
          }
          pageContext.setAttribute("connector", connector, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n");
      project.UserInfo userInfo = null;
      synchronized (application) {
        userInfo = (project.UserInfo) pageContext.getAttribute("userInfo", PageContext.APPLICATION_SCOPE);
        if (userInfo == null){
          try {
            userInfo = (project.UserInfo) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.UserInfo");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.UserInfo", exc);
          }
          pageContext.setAttribute("userInfo", userInfo, PageContext.APPLICATION_SCOPE);
        }
      }
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n\r\n\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n\r\n");
      out.write("<meta name=\"GENERATOR\" content=\"Microsoft FrontPage 5.0\">\r\n");
      out.write("<meta name=\"ProgId\" content=\"FrontPage.Editor.Document\">\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1256\">\r\n\r\n");
      out.write("<title>\r\nfindRecieved\r\n");
      out.write("</title>\r\n");
      out.write("</head>\r\n");
      out.write("<body bgcolor=\"#eeeeee\"  link=\"#200000\"  Vlink=\"#ffffff\">\r\n");
 if(userInfo.getPos_id()==-1){ 
      out.write("\r\n    ");
      if (true) {
        pageContext.forward("error.htm");
        return;
      }
      out.write("\r\n\r\n");
 }else{
      out.write("\r\n\r\n ");
      out.write("<p align=\"center\">\r\n");
      out.write("<a href=\"inbox.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>inbox");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"outbox.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>outbox");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"sendPageGenerator.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>send doc");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"reporting.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>reporting");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"changeUserPass.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>changePassword");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"helpFiles/help.htm\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>help&amp;support");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>");
      out.write("</p>\r\n  ");
      out.write("<h1 align=\"center\">");
      out.write("<font color=\"#800000\" size=\"5\">");
      out.write("<i>Reporting");
      out.write("</i>");
      out.write("</font>");
      out.write("</h1>\r\n\r\n  ");
      out.write("<!-- -->\r\n ");
int b=0;
   String doc_serial="";
   Timestamp  doc_date;
   String  pos_id="";
   String pos_name="";
   String doc_ids="";
   String month1=request.getParameter("month1");
   String year1=request.getParameter("year1");
   String day1=request.getParameter("day1");
   String month2=request.getParameter("month2");
   String year2=request.getParameter("year2");
   String day2=request.getParameter("day2");
   Timestamp date=new Timestamp(0,0,0,0,0,0,0);
   Timestamp date1=new Timestamp(0,0,0,0,0,0,0);
   Timestamp date2=new Timestamp(0,0,0,0,0,0,0);
   int dd1=0,mm1=0,yyyy1=0;
   int dd2=0,mm2=0,yyyy2=0;

   try{ //check date format
      dd1=Integer.valueOf(day1).intValue();
      mm1=Integer.valueOf(month1).intValue();
      yyyy1=Integer.valueOf(year1).intValue();
      dd2=Integer.valueOf(day2).intValue();
      mm2=Integer.valueOf(month2).intValue();
      yyyy2=Integer.valueOf(year2).intValue();
   }
   catch(NumberFormatException e){
      
      out.write(" ");
      out.write("<h3> the date parameters are wrong, check it again");
      out.write("</h3> ");

   }

   //check date for value errors
   if((!((dd1>0)&&(dd1<32)&&(mm1<13)&&(mm1>0)&&(yyyy1<2050)&&(yyyy1>1980))) &&(!((dd2>0)&&(dd2<32)&&(mm2<13)&&(mm2>0)&&(yyyy2<2050)&&(yyyy2>1980)))){
   b=1;
      
      out.write("<h3> error: date is invalid ");
      out.write("</h3>");

   }else{ //continue
   yyyy1=yyyy1-1900;
   yyyy2=yyyy2-1900;
   mm1=mm1-1;
   mm2=mm2-1;
   date1=new Timestamp(yyyy1,mm1,dd1,0,0,0,0);
   date2=new Timestamp(yyyy2,mm2,dd2,0,0,0,0);
   }
     try{
      ResultSet r;
      r=connector.executeQuery("SELECT COUNT(pos_id) FROM position");
      int count=0;
      int i=0;
      if(r.next()){
      count=r.getInt(1);
      }
      r=connector.executeQuery("SELECT pos_id,pos_name FROM position");
      String [][] pos=new String [count][2];
      while((r.next())&&(i<count)){
      pos[i][0]=r.getString("pos_id");
      pos[i][1]=r.getString("pos_name");
      ++i;
      }
     ResultSet link=connector.executeQuery("SELECT from_pos,doc_serial,doc_date,note_date FROM history WHERE  to_pos="+userInfo.getPos_id());
     while(link.next()){
        pos_id=link.getString("from_pos");
        doc_serial=link.getString("doc_serial");
        doc_date=link.getTimestamp("doc_date");
        date=link.getTimestamp("note_date");
        doc_ids=doc_serial+"*"+doc_date.getTime()+"*";
        int j=0;
        while (j<count){
          if (pos[j][0].equals(pos_id)){
           pos_name=pos[j][1];
           }
          j++;
        }
        if ((date1.before(date)) && (date.before(date2))) {
           b=1;
      out.write("\r\n           ");
      out.write("<img border=\"0\" src=\"images/11.gif\" width=\"20\" height=\"20\">&nbsp;\r\n          ");
      out.write("<a href=\"viewContent.jsp?doc_ids=");
      out.print( doc_ids );
      out.write("\">");
      out.write("<b>message frome ");
      out.print(pos_name);
      out.write(" at ");
      out.print( date );
      out.write("</b> ");
      out.write("</a> ");
      out.write("<br>\r\n     ");
 } }

     if (b==0){
      out.write("\r\n       ");
      out.write("<p> ");
      out.write("<b>");
      out.write("<font color=\"#666666\" size=\"4\"> there is no document ");
      out.write("</font>");
      out.write("</b>");
      out.write("</p>\r\n     ");
}
    }catch(SQLException e){
      out.write("\r\n        ");
      out.write("<h2> SQL error:");
      out.write("</h2> ");
      out.print( e.toString() );
      out.write("\r\n  ");
 }} 
      out.write("\r\n\r\n");
      out.write("<p align=\"right\">");
      out.write("<a href=\"homepage.jsp\">");
      out.write("<img border=\"0\" src=\"images/60.gif\" width=\"72\" height=\"29\">");
      out.write("</a>");
      out.write("</p>\r\n");
      out.write("<form method=\"POST\" action=\"SignOut.jsp\">\r\n  ");
      out.write("<p>\r\n  ");
      out.write("<input type=\"submit\" value=\"sign out\" name=\"signout\">");
      out.write("</p>\r\n");
      out.write("</form>\r\n\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n\r\n");
    } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }
}
