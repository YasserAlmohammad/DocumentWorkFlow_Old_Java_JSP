import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;
import java.sql.*;
import java.util.StringTokenizer;

public class createPath_0002ejsp_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  static {
    _jspx_includes = new java.util.Vector(1);
    _jspx_includes.add("/ConnectInclude.jsp");
  }

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      project.Connect connector = null;
      synchronized (session) {
        connector = (project.Connect) pageContext.getAttribute("connector", PageContext.SESSION_SCOPE);
        if (connector == null){
          try {
            connector = (project.Connect) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.Connect");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.Connect", exc);
          }
          pageContext.setAttribute("connector", connector, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n");
      project.UserInfo userInfo = null;
      synchronized (application) {
        userInfo = (project.UserInfo) pageContext.getAttribute("userInfo", PageContext.APPLICATION_SCOPE);
        if (userInfo == null){
          try {
            userInfo = (project.UserInfo) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.UserInfo");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.UserInfo", exc);
          }
          pageContext.setAttribute("userInfo", userInfo, PageContext.APPLICATION_SCOPE);
        }
      }
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n\r\n");
      out.write("<meta name=\"GENERATOR\" content=\"Microsoft FrontPage 5.0\">\r\n");
      out.write("<meta name=\"ProgId\" content=\"FrontPage.Editor.Document\">\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">\r\n\r\n");
      out.write("<title>\r\ncreatePath page handler\r\n");
      out.write("</title>\r\n");
      out.write("</head>\r\n");
      out.write("<body bgcolor=\"#eeeeee\">\r\n\r\n");
 if(userInfo.getPos_id()<0){ //any one can't use any page without signing in, he may see the forms, but can't use them
   
      out.write(" ");
      if (true) {
        pageContext.forward("error.htm");
        return;
      }
      out.write("\r\n");
} 
      out.write("\r\n\r\n\r\n");
 String pos_chain=request.getParameter("address_chain");
   String path_name=request.getParameter("path_name");
   String template=request.getParameter("template");
   StringTokenizer tokens=new StringTokenizer(pos_chain,"*");
   String pos_name="";
   String address_chain="";
   String oldToken="";
   if(path_name.equals("")){ //don't allow empty named path
      
      out.write(" ");
      out.write("<h3> some fields are missing, please fill the form again ");
      out.write("</h3> ");

   }
   else{
   boolean listIsOk=true;
   //first test if path name is valid: if it's already exsists or if it was empty
   // we can ignore this as an exeption will be fired if name was repeated
   try{
     //we can check the path content if it holds any mistakes
     while((tokens.hasMoreTokens())&&(listIsOk)){
      pos_name=tokens.nextToken();
      if(pos_name.equals(oldToken)) //this case won't happen any way, because we made the check on the client side
        listIsOk=false;             // but we'll keep any way
      oldToken=pos_name;
      // parse the position name to id
      ResultSet pos_id=connector.executeQuery("SELECT pos_id FROM position WHERE pos_name='"+pos_name+"'");
      if(pos_id.next()){
        address_chain=address_chain+pos_id.getString("pos_id")+" ";
      }
      else{
        listIsOk=false;
      }
     }
     if(listIsOk){
         connector.executeUpdate("INSERT INTO path (path_name,address_chain,template) VALUES ('"+path_name+"','"+address_chain+"','"+template+"')");
        
      out.write(" ");
      out.write("<h1> new path was succefully created ");
      out.write("</h1> ");

     }
     else{ 
      out.write("\r\n        ");
      out.write("<br> error in the path content, or doublicated position( trying to send to your self directly)\r\n   ");
}
   }
    catch(Exception e){
      
      out.write(" ");
      out.write("<h1> error ");
      out.write("</h1> ");
      out.print( e.toString() );
      out.write("\r\n   ");
 }
   }
      out.write("\r\n\r\n\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }
}
