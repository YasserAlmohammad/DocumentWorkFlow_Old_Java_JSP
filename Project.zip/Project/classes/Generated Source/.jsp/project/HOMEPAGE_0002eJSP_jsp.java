import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;
import java.sql.*;
import java.util.StringTokenizer;

public class HOMEPAGE_0002eJSP_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  static {
    _jspx_includes = new java.util.Vector(1);
    _jspx_includes.add("/ConnectInclude.jsp");
  }

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=windows-1256");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      project.Connect connector = null;
      synchronized (session) {
        connector = (project.Connect) pageContext.getAttribute("connector", PageContext.SESSION_SCOPE);
        if (connector == null){
          try {
            connector = (project.Connect) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.Connect");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.Connect", exc);
          }
          pageContext.setAttribute("connector", connector, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n");
      project.UserInfo userInfo = null;
      synchronized (application) {
        userInfo = (project.UserInfo) pageContext.getAttribute("userInfo", PageContext.APPLICATION_SCOPE);
        if (userInfo == null){
          try {
            userInfo = (project.UserInfo) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.UserInfo");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.UserInfo", exc);
          }
          pageContext.setAttribute("userInfo", userInfo, PageContext.APPLICATION_SCOPE);
        }
      }
      out.write("\r\n");
      out.write("\r\n\r\n");
      out.write("<html>\r\n\r\n");
      out.write("<head>\r\n\r\n");
      out.write("<meta name=\"GENERATOR\" content=\"Microsoft FrontPage 5.0\">\r\n");
      out.write("<meta name=\"ProgId\" content=\"FrontPage.Editor.Document\">\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1256\">\r\n\r\n");
      out.write("<title>homepage");
      out.write("</title>\r\n");
      out.write("</head>\r\n\r\n");
      out.write("<body bgcolor=\"#eeeeee\">\r\n\r\n\r\n");
 if(userInfo.getPos_id()<0){ //any one can't use any page without signing in, he may see the forms, but can't use them
   
      out.write(" ");
      if (true) {
        pageContext.forward("error.htm");
        return;
      }
      out.write("\r\n");
} 
      out.write("\r\n\r\n\r\n");
 ResultSet r=connector.executeQuery("SELECT username FROM users WHERE pos_id="+userInfo.getPos_id());
   String username="";
   if(r.next())
     username=r.getString("username");

      out.write("\r\n\r\n");
      out.write("<p>");
      out.write("<font color=\"#800000\" size=\"6\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\nW");
      out.write("</font>");
      out.write("<font color=\"#800000\" size=\"4\">elcome\r\n");
      out.print(username);
      out.write(" to your Home Page&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ");
      out.write("</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n");
      out.write("</p>\r\n");
      out.write("<p align=\"center\">");
      out.write("<img border=\"0\" src=\"images/mmm.gif\" width=\"140\" height=\"56\">");
      out.write("</p>\r\n");
      out.write("<h3 align=\"center\">");
      out.write("<a href=\"inbox.jsp\">");
      out.write("<font color=\"#000000\">");
      out.write("<b>inbox");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>");
      out.write("</h3>\r\n");
      out.write("<h3 align=\"center\">");
      out.write("<a href=\"outbox.jsp\">");
      out.write("<font color=\"#000000\">");
      out.write("<b>outbox");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>");
      out.write("</h3>\r\n");
      out.write("<h3 align=\"center\">");
      out.write("<a href=\"sendPageGenerator.jsp\">");
      out.write("<font color=\"#000000\">");
      out.write("<b>send doc");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>");
      out.write("</h3>\r\n");
      out.write("<h3 align=\"center\">");
      out.write("<a href=\"reporting.jsp\">");
      out.write("<font color=\"#000000\">");
      out.write("<b>reporting");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>");
      out.write("</h3>\r\n");
      out.write("<h3 align=\"center\">");
      out.write("<a href=\"changeUserPass.jsp\">");
      out.write("<font color=\"#000000\">");
      out.write("<b>changePassword");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>");
      out.write("</h3>\r\n");
      out.write("<h3 align=\"center\">");
      out.write("<a href=\"helpFiles/help.htm\">");
      out.write("<font color=\"#000000\">");
      out.write("<b>help&amp;support");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>");
      out.write("</h3>\r\n");
      out.write("<h3 align=\"center\">");
      out.write("<a href=\"help/new_page_1.htm\">");
      out.write("<font color=\"#000000\">");
      out.write("<b>help&amp;support 2nd version");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>");
      out.write("</h3>\r\n\r\n");
      out.write("<form method=\"POST\" action=\"SignOut.jsp\">\r\n  ");
      out.write("<!--webbot bot=\"SaveResults\" U-File=\"_private/form_results.csv\" S-Format=\"TEXT/CSV\" S-Label-Fields=\"TRUE\" startspan -->");
      out.write("<input TYPE=\"hidden\" NAME=\"VTI-GROUP\" VALUE=\"0\">");
      out.write("<!--webbot bot=\"SaveResults\" i-checksum=\"43374\" endspan -->");
      out.write("<p>\r\n  ");
      out.write("<input type=\"submit\" value=\"signout\" name=\"signout\">");
      out.write("</p>\r\n");
      out.write("</form>\r\n");
      out.write("<p align=\"left\">&nbsp;");
      out.write("</p>\r\n\r\n");
      out.write("</body>\r\n\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }
}
