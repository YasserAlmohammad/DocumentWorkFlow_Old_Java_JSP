import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;
import java.sql.*;
import java.util.StringTokenizer;

public class sendPageGenerator_0002ejsp_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  static {
    _jspx_includes = new java.util.Vector(1);
    _jspx_includes.add("/ConnectInclude.jsp");
  }

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      project.Connect connector = null;
      synchronized (session) {
        connector = (project.Connect) pageContext.getAttribute("connector", PageContext.SESSION_SCOPE);
        if (connector == null){
          try {
            connector = (project.Connect) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.Connect");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.Connect", exc);
          }
          pageContext.setAttribute("connector", connector, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n");
      project.UserInfo userInfo = null;
      synchronized (application) {
        userInfo = (project.UserInfo) pageContext.getAttribute("userInfo", PageContext.APPLICATION_SCOPE);
        if (userInfo == null){
          try {
            userInfo = (project.UserInfo) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.UserInfo");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.UserInfo", exc);
          }
          pageContext.setAttribute("userInfo", userInfo, PageContext.APPLICATION_SCOPE);
        }
      }
      out.write("\r\n");
      out.write("\r\n\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n\r\n");
      out.write("<meta name=\"GENERATOR\" content=\"Microsoft FrontPage 5.0\">\r\n");
      out.write("<meta name=\"ProgId\" content=\"FrontPage.Editor.Document\">\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">\r\n\r\n");
      out.write("<title>sending new document&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n");
      out.write("</title>\r\n\r\n\r\n");
      out.write("<SCRIPT language=\"javascript\">\r\n\r\n//we'll change the form destination according to the submit button click\r\n\r\nfunction sendClick(){\r\n  document.send.action=\"send.jsp\"  // the default\r\n}\r\n\r\nfunction loadClick(){\r\n  document.send.action=\"sendPageGenerator.jsp\"\r\n}\r\n\r\nfunction pathChange(){\r\n  document.send.loadTemplate.click();\r\n\r\n}\r\n\r\n");
      out.write("</script>\r\n\r\n");
      out.write("</head>\r\n");
      out.write("<body bgcolor=\"#eeeeee\">\r\n");
 if(userInfo.getPos_id()<0){  //security matter: if you are not signed in you can't see this page
      
      out.write(" ");
      if (true) {
        pageContext.forward("error.htm");
        return;
      }
      out.write("\r\n ");
}

      out.write("\r\n\r\n");
      out.write("<p align=\"center\">\r\n");
      out.write("<a href=\"inbox.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>inbox");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"outbox.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>outbox");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"sendPageGenerator.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>send doc");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"reporting.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>reporting");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"changeUserPass.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>changePassword");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"helpFiles/help.htm\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>help&amp;support");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>");
      out.write("</p>\r\n");
      out.write("<h1 align=\"center\">");
      out.write("<font color=\"#800000\" size=\"5\">");
      out.write("<b>");
      out.write("<i>sending new document&nbsp;");
      out.write("</i>");
      out.write("</b>");
      out.write("<i>&nbsp;\r\n");
      out.write("</i>");
      out.write("</font>");
      out.write("<font size=\"5\">&nbsp;&nbsp; ");
      out.write("</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n");
      out.write("</h1>\r\n");
      out.write("<p align=\"left\">");
      out.write("<font color=\"#000000\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n");
      out.write("</font>");
      out.write("<font color=\"#000000\">");
      out.write("<img border=\"0\" src=\"images/D4.gif\" width=\"105\" height=\"78\">");
      out.write("</font>");
      out.write("</p>\r\n\r\n");
      out.write("<p align=\"left\">");
      out.write("<b>");
      out.write("<font color=\"#808080\">please fill the existing fields and\r\nthey will be automatically completed");
      out.write("</font>");
      out.write("</b>");
      out.write("</p>\r\n");
      out.write("<p align=\"left\">");
      out.write("<b>");
      out.write("<font color=\"#808080\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\nuse ");
      out.write("</font>");
      out.write("<a href=\"helpFiles/help.htm\">");
      out.write("<font color=\"#000080\"> help");
      out.write("</font>");
      out.write("</a>");
      out.write("<font color=\"#808080\"> for more information on how this works");
      out.write("</font>");
      out.write("</b>");
      out.write("</p>\r\n");
      out.write("<!-- the jsp generation code -->\r\n\r\n");
      out.write("<form name=\"send\" method=\"POST\" action=\"send.jsp\" >\r\n  ");
      out.write("<p>\r\n  ");
String path_val=request.getParameter("path_name");
    String template="";
    try{
      //String path_name=request.getParameter("path_name");
      
      out.write(" ");
      out.write("<hr> ");

      ResultSet r=connector.executeQuery("SELECT template,address_chain FROM path WHERE path_name='"+path_val+"'");
      if(r.next()){ //view the positions representing the path
        template=r.getString("template");
        StringTokenizer tokens=new StringTokenizer(r.getString("address_chain"));
        if(tokens.hasMoreTokens())
           tokens.nextToken(); //skip your self
        
      out.print( path_val);
      out.write(" path will follow this way:");
      out.write("<br>from you ");

        while(tokens.hasMoreTokens()){
          String pos_id=tokens.nextToken();
          r=connector.executeQuery("SELECT pos_name FROM position WHERE pos_id="+pos_id);
          if(r.next()){
            
      out.write(" --> ");
      out.print( r.getString("pos_name") );
      out.write(" ");

         }
        }
      }
      
      out.write(" ");
      out.write("<hr>\r\n\r\n  select path for your document:");
      out.write("<span lang=\"ar-sy\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n  ");
      out.write("</span>&nbsp;");
      out.write("<select size=\"1\" name=\"path_name\" onChange=\"pathChange()\">\r\n   ");
      out.write("<option selected value=\"");
      out.print(path_val);
      out.write("\">");
      out.print(path_val);
      out.write("</option>\r\n  ");

   /*imporant:
     we'll view only paths that begins with the current user, means: only paths he defined can be
     viewed or used by him, this way we increase the security and the program will be more trusted
     so he can't use paths defined by others
   */
   String address_chain="",path_name="";
   ResultSet paths=connector.executeQuery("SELECT path_name,address_chain FROM Path");
   while(paths.next()){
       path_name=paths.getString("path_name");
       address_chain=paths.getString("address_chain");
       //now see if the begining of the path is the current user, if yes: let it available
       StringTokenizer posTokens=new StringTokenizer(address_chain);
       int dept_pos=-1;
       if(posTokens.hasMoreElements()){
        dept_pos=Integer.valueOf(posTokens.nextToken()).intValue();
        if((dept_pos==userInfo.getPos_id())||(path_name.equals("manual"))){ //ok, user can use this path
          
      out.write("\r\n          ");
      out.write("<option value=\"");
      out.print( path_name);
      out.write("\"> ");
      out.print(path_name );
      out.write("</option>\r\n        ");
}
       }
   } 
      out.write("\r\n\r\n  ");
      out.write("</select>\r\n  ");
      out.write("<input type=\"submit\" value=\"load template\" name=\"loadTemplate\" onClick=\"loadClick()\">");
      out.write("</p>\r\n  ");
      out.write("<p>if you selected manual as path type select the position you want to send\r\n  it for&nbsp;&nbsp;\r\n  ");
      out.write("<select size=\"1\" name=\"pos_name\">\r\n\r\n");

   // view all positions available for manual direcing
   String pos_name="",pos_id;

   //administrator is not count, and you can't send message to your self directly
   ResultSet poss=connector.executeQuery("SELECT pos_name,pos_id FROM position WHERE pos_name<> 'administrator' AND pos_id<>"+userInfo.getPos_id());
   while(poss.next()){
       pos_name=poss.getString("pos_name");
       pos_id=poss.getString("pos_id");
      //we can know everything about user from pos_id
       
      out.write("\r\n\r\n       ");
      out.write("<option value=\"");
      out.print( pos_id );
      out.write("\"> ");
      out.print(pos_name );
      out.write("</option>\r\n   ");
}


   }catch(SQLException e){ 
      out.write("\r\n    ");
      out.write("<h1> SQL error ");
      out.write("<h1> ");
      out.print(e.toString() );
      out.write("\r\n");
 } 
      out.write("\r\n  ");
      out.write("</select>");
      out.write("</p>\r\n\r\n  ");
      out.write("<p>you can define new path, if your document type will be frequently used,\r\n  click here\r\n  ");
      out.write("<a href=\"newPath.jsp\"> define new path");
      out.write("</a> ");
      out.write("</p>\r\n  number on document(required, like 232EF88D8) :  ");
      out.write("<input type=\"text\" name=\"num_on_doc\" size=\"25\">\r\n  ");
      out.write("<p>date on document i.e 22-3-2003 :\r\n  ");
      out.write("<input type=\"text\" name=\"day\" size=\"2\" >\r\n  ");
      out.write("<input type=\"text\" name=\"month\" size=\"2\" >\r\n  ");
      out.write("<input type=\"text\" name=\"year\" size=\"4\" >\r\n  ");
      out.write("<input type=\"hidden\" name=\"path_val\" value=\"");
      out.print(path_val);
      out.write("\">\r\n  ");
      out.write("</p>\r\n  ");
      out.write("<p>");
      out.write("<textarea rows=\"10\" name=\"content\" cols=\"100\">");
      out.print(template);
      out.write("</textarea>");
      out.write("</p>\r\n  ");
      out.write("<p align=\"left\">");
      out.write("<font >");
      out.write("<b>if you have a note write it below");
      out.write("</b>");
      out.write("</font>");
      out.write("</p>\r\n  ");
      out.write("<p align=\"left\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n  ");
      out.write("<textarea rows=\"6\" name=\"note\" cols=\"72\">");
      out.write("</textarea>");
      out.write("</p>\r\n  ");
      out.write("<p>");
      out.write("<u>");
      out.write("<input type=\"submit\" value=\"send documnet\" name=\"send\">");
      out.write("<input type=\"reset\" value=\"   Reset form   \" name=\"B2\">");
      out.write("</u>");
      out.write("</p>\r\n\r\n");
      out.write("</form>\r\n");
      out.write("<p align=\"right\">");
      out.write("<a href=\"homepage.jsp\">");
      out.write("<img border=\"0\" src=\"images/60.gif\" width=\"72\" height=\"29\">");
      out.write("</a>");
      out.write("</p>\r\n");
      out.write("<form method=\"POST\" action=\"SignOut.jsp\">\r\n  ");
      out.write("<p>\r\n  ");
      out.write("<input type=\"submit\" value=\"sign out\" name=\"signout\">");
      out.write("</p>\r\n");
      out.write("</form>\r\n\r\n");
      out.write("</body>\r\n\r\n");
      out.write("</html>");
    } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }
}
