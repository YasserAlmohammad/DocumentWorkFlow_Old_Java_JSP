import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;
import java.sql.*;
import java.util.StringTokenizer;

public class workLoad_0002ejsp_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  static {
    _jspx_includes = new java.util.Vector(1);
    _jspx_includes.add("/ConnectInclude.jsp");
  }

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=windows-1256");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      project.Connect connector = null;
      synchronized (session) {
        connector = (project.Connect) pageContext.getAttribute("connector", PageContext.SESSION_SCOPE);
        if (connector == null){
          try {
            connector = (project.Connect) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.Connect");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.Connect", exc);
          }
          pageContext.setAttribute("connector", connector, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n");
      project.UserInfo userInfo = null;
      synchronized (application) {
        userInfo = (project.UserInfo) pageContext.getAttribute("userInfo", PageContext.APPLICATION_SCOPE);
        if (userInfo == null){
          try {
            userInfo = (project.UserInfo) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.UserInfo");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.UserInfo", exc);
          }
          pageContext.setAttribute("userInfo", userInfo, PageContext.APPLICATION_SCOPE);
        }
      }
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<title>\r\nworkLoad\r\n");
      out.write("</title>\r\n");
      out.write("</head>\r\n");
      out.write("<body bgcolor=\"#eeeeee\">\r\n\r\n");
      out.write("<br>\r\n");
      out.write("<table border=\"2\" cellpadding=\"1\" cellspacing=\"1\">\r\n  ");
      out.write("<tr>\r\n    ");
      out.write("<td>position name");
      out.write("</td>\r\n    ");
      out.write("<td>number of incoming documents");
      out.write("</td>\r\n    ");
      out.write("<td>number of out going documnets ");
      out.write("</td>\r\n  ");
      out.write("</tr>\r\n\r\n");
 // first the arriving documents
try{
  ResultSet workLoad=connector.executeQuery("SELECT COUNT(pos_id) FROM position");
  int count=0,i=0;
  if(workLoad.next()){
    count=workLoad.getInt(1);
  }
  workLoad=connector.executeQuery("SELECT pos_id,pos_name FROM position");
  String [][] pos=new String [count][2];
  while((workLoad.next())&&(i<count)){
    pos[i][0]=workLoad.getString("pos_id");
    pos[i][1]=workLoad.getString("pos_name");
    ++i;
  }
  i=0;
  while(i<count){
    
      out.write(" ");
      out.write("<tr>\r\n          ");
      out.write("<td> ");
      out.print( pos[i][1] );
      out.write(" ");
      out.write("</td> ");

    workLoad=connector.executeQuery("SELECT count(from_pos) FROM history WHERE from_pos="+pos[i][0]);
    if(workLoad.next()){
       
      out.write(" ");
      out.write("<td>");
      out.print( workLoad.getString(1) );
      out.write(" ");
      out.write("</td> ");

    }
    workLoad=connector.executeQuery("SELECT count(to_pos) FROM history WHERE to_pos="+pos[i][0]);
    if(workLoad.next()){
       
      out.write(" ");
      out.write("<td>");
      out.print( workLoad.getString(1) );
      out.write(" ");
      out.write("</td> ");

    }
    
      out.write(" ");
      out.write("<tr> ");

    ++i;
  }
  //out going documents number
}catch(SQLException e){ 
      out.write(" ");
      out.print(e.toString() );
      out.write(" ");
 }

      out.write("\r\n\r\n");
      out.write("</table>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }
}
