import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;
import java.sql.*;
import java.util.StringTokenizer;

public class getDocsFrom_0002ejsp_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  static {
    _jspx_includes = new java.util.Vector(1);
    _jspx_includes.add("/ConnectInclude.jsp");
  }

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=windows-1256");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      project.Connect connector = null;
      synchronized (session) {
        connector = (project.Connect) pageContext.getAttribute("connector", PageContext.SESSION_SCOPE);
        if (connector == null){
          try {
            connector = (project.Connect) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.Connect");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.Connect", exc);
          }
          pageContext.setAttribute("connector", connector, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n");
      project.UserInfo userInfo = null;
      synchronized (application) {
        userInfo = (project.UserInfo) pageContext.getAttribute("userInfo", PageContext.APPLICATION_SCOPE);
        if (userInfo == null){
          try {
            userInfo = (project.UserInfo) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.UserInfo");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.UserInfo", exc);
          }
          pageContext.setAttribute("userInfo", userInfo, PageContext.APPLICATION_SCOPE);
        }
      }
      out.write("\r\n");
      out.write("\r\n\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n\r\n");
      out.write("<meta name=\"GENERATOR\" content=\"Microsoft FrontPage 5.0\">\r\n");
      out.write("<meta name=\"ProgId\" content=\"FrontPage.Editor.Document\">\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1256\">\r\n\r\n");
      out.write("<title>\r\nsearch messages from position\r\n");
      out.write("</title>\r\n");
      out.write("</head>\r\n");
      out.write("<body bgcolor=\"#eeeeee\"  link=\"#200000\"  Vlink=\"#ffffff\">\r\n");
 if(userInfo.getPos_id()==-1){ 
      out.write("\r\n    ");
      if (true) {
        pageContext.forward("error.htm");
        return;
      }
      out.write("\r\n\r\n");
 }else{
      out.write("\r\n\r\n  ");
      out.write("<p align=\"center\">\r\n");
      out.write("<a href=\"inbox.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>inbox");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"outbox.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>outbox");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"sendPageGenerator.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>send doc");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"reporting.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>reporting");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"changeUserPass.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>changePassword");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"helpFiles/help.htm\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>help&amp;support");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>");
      out.write("</p>\r\n  ");
      out.write("<h1 align=\"center\">");
      out.write("<font color=\"#800000\" size=\"5\">");
      out.write("<i>Reporting");
      out.write("</i>");
      out.write("</font>");
      out.write("</h1>\r\n     ");

     int b=0;
     String pos_name= request.getParameter("pos_name");
     String doc_serial="";
     Timestamp doc_date,note_date;
     String pos_id="";
     String doc_ids="";
     try{
     ResultSet dep_id=connector.executeQuery("SELECT pos_id FROM position WHERE pos_name='"+pos_name+"'");
     if (dep_id.next()){
        pos_id=dep_id.getString("pos_id");
     }

     ResultSet link=connector.executeQuery("SELECT doc_serial,doc_date,note_date FROM history WHERE to_pos="+userInfo.getPos_id() + "AND from_pos="+pos_id);
     while(link.next()){
        b=1;
        doc_serial=link.getString("doc_serial");
        doc_date=link.getTimestamp("doc_date");
        note_date=link.getTimestamp("note_date");
        doc_ids=doc_serial+"*"+doc_date.getTime()+"*";
      out.write("\r\n        ");
      out.write("<img border=\"0\" src=\"images/11.gif\" width=\"20\" height=\"20\">&nbsp;\r\n        ");
      out.write("<a href=\"viewContent.jsp?doc_ids=");
      out.print( doc_ids );
      out.write("\">");
      out.write("<b>message from ");
      out.print(pos_name);
      out.write(" at ");
      out.print( note_date );
      out.write(" ");
      out.write("</b>");
      out.write("</a>");
      out.write("<br>\r\n\r\n\r\n    ");
}
     if (b==0){
      out.write("\r\n       ");
      out.write("<p> ");
      out.write("<b>");
      out.write("<font color=\"#666666\" size=\"4\"> there is no document ");
      out.write("</font>");
      out.write("</b>");
      out.write("</p>\r\n     ");
}
      }catch(SQLException e){
      out.write("\r\n        ");
      out.write("<h2> SQL error:");
      out.write("</h2> ");
      out.print( e.toString() );
      out.write("\r\n  ");
 }} 
      out.write("\r\n\r\n");
      out.write("<p align=\"right\">");
      out.write("<a href=\"homepage.jsp\">");
      out.write("<img border=\"0\" src=\"images/60.gif\" width=\"72\" height=\"29\">");
      out.write("</a>");
      out.write("</p>\r\n");
      out.write("<form method=\"POST\" action=\"SignOut.jsp\">\r\n  ");
      out.write("<p>\r\n  ");
      out.write("<input type=\"submit\" value=\"sign out\" name=\"signout\">");
      out.write("</p>\r\n");
      out.write("</form>\r\n\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n\r\n");
    } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }
}
