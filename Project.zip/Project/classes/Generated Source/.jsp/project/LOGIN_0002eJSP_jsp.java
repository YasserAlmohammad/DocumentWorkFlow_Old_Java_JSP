import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;
import java.sql.*;
import java.util.StringTokenizer;

public class LOGIN_0002eJSP_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  static {
    _jspx_includes = new java.util.Vector(1);
    _jspx_includes.add("/ConnectInclude.jsp");
  }

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      project.Connect connector = null;
      synchronized (session) {
        connector = (project.Connect) pageContext.getAttribute("connector", PageContext.SESSION_SCOPE);
        if (connector == null){
          try {
            connector = (project.Connect) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.Connect");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.Connect", exc);
          }
          pageContext.setAttribute("connector", connector, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n");
      project.UserInfo userInfo = null;
      synchronized (application) {
        userInfo = (project.UserInfo) pageContext.getAttribute("userInfo", PageContext.APPLICATION_SCOPE);
        if (userInfo == null){
          try {
            userInfo = (project.UserInfo) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.UserInfo");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.UserInfo", exc);
          }
          pageContext.setAttribute("userInfo", userInfo, PageContext.APPLICATION_SCOPE);
        }
      }
      out.write("\r\n");
      out.write("\r\n\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<title>\r\nlogin ensurance\r\n");
      out.write("</title>\r\n");
      out.write("</head>\r\n\r\n");
      out.write("<meta name=\"GENERATOR\" content=\"Microsoft FrontPage 5.0\">\r\n");
      out.write("<meta name=\"ProgId\" content=\"FrontPage.Editor.Document\">\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1256\">\r\n\r\n");
      out.write("<body bgcolor=\"#eeeeee\">\r\n");
      out.write("<h1>\r\nTesting user authentication\r\n");
      out.write("</h1>\r\n\r\n");
 String user=request.getParameter("username"),pass=request.getParameter("password");

  try{
      connector.connect("jdbc:odbc:project","","");
      ResultSet r=connector.executeQuery("SELECT pos_id,username,password,enddate,startdate FROM users WHERE username='"+user+"' AND password='"+pass+"'");
      if(r.next()){
         userInfo.setPos_id(r.getInt("pos_id"));
         Timestamp endDate=r.getTimestamp("enddate"); //check user have access any more
         Timestamp startDate=r.getTimestamp("startdate");
         Timestamp sysDate=new Timestamp(System.currentTimeMillis());
         if("admin".equals(user.toLowerCase())){ 
      out.write("\r\n            ");
      if (true) {
        pageContext.forward("administrator.htm");
        return;
      }
      out.write("\r\n        ");
 }else{
                 if((endDate==null)||(endDate.after(sysDate))){ //make sure the user still valid
                    if(startDate.before(sysDate)){ // he starts after the current time
                      
      out.write(" ");
      if (true) {
        pageContext.forward("homepage.jsp");
        return;
      }
      out.write("\r\n                    ");
}
                    else{
                        connector.disconnect();
                        userInfo.setPos_id(-1);
      out.write(" you dont have access yet, you can access the system after ");
      out.print( startDate );
      out.write(" ");

                    }
                 }
                 else{
                    connector.disconnect();
                    userInfo.setPos_id(-1); 
      out.write(" you don't have access anymore, contact Administartor for more information ");
}
            }
      }else{
            connector.disconnect();
      out.write("\r\n         ");
      out.print(user );
      out.write(" you are invalid user, try a gain\r\n");
  }
    }catch(Exception e){ 
      out.write("\r\n    ");
      out.write("<p> error ");
      out.write("</p> ");
      out.print( e.getMessage() );
      out.write("\r\n");
}
      out.write("\r\n\r\n\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }
}
