import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;
import java.sql.*;
import java.util.StringTokenizer;

public class createAccount_0002ejsp_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  static {
    _jspx_includes = new java.util.Vector(1);
    _jspx_includes.add("/ConnectInclude.jsp");
  }

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      project.Connect connector = null;
      synchronized (session) {
        connector = (project.Connect) pageContext.getAttribute("connector", PageContext.SESSION_SCOPE);
        if (connector == null){
          try {
            connector = (project.Connect) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.Connect");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.Connect", exc);
          }
          pageContext.setAttribute("connector", connector, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n");
      project.UserInfo userInfo = null;
      synchronized (application) {
        userInfo = (project.UserInfo) pageContext.getAttribute("userInfo", PageContext.APPLICATION_SCOPE);
        if (userInfo == null){
          try {
            userInfo = (project.UserInfo) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.UserInfo");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.UserInfo", exc);
          }
          pageContext.setAttribute("userInfo", userInfo, PageContext.APPLICATION_SCOPE);
        }
      }
      out.write("\r\n");
      out.write("\r\n\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n\r\n");
      out.write("<meta name=\"GENERATOR\" content=\"Microsoft FrontPage 5.0\">\r\n");
      out.write("<meta name=\"ProgId\" content=\"FrontPage.Editor.Document\">\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">\r\n\r\n");
      out.write("<title>\r\ncreateAccount\r\n");
      out.write("</title>\r\n");
      out.write("</head>\r\n");
      out.write("<body bgcolor=\"#eeeeee\">\r\n\r\n");
 if(userInfo.getPos_id()<0){ //any one can't use any page without signing in, he may see the forms, but can't use them
   
      out.write(" ");
      if (true) {
        pageContext.forward("error.htm");
        return;
      }
      out.write("\r\n");
} 
      out.write("\r\n\r\n\r\n");

   // first get the Parameters
   String newUser=request.getParameter("username"),newPass=request.getParameter("password");
   String pos_name=request.getParameter("description"),confirmPass=request.getParameter("confirmPass");
   String startDD=request.getParameter("startDD"),startMM=request.getParameter("startMM"),startYYYY=request.getParameter("startYYYY"),
   endDD=request.getParameter("endDD"),endMM=request.getParameter("endMM"),endYYYY=request.getParameter("endYYYY"),
   allow_def=request.getParameter("allow_def");

   int sDD=0,sMM=0,sYYYY=0;
   int eDD=0,eMM=0,eYYYY=0;
   try{ // check date format
      sDD=Integer.valueOf(startDD).intValue();
      sMM=Integer.valueOf(startMM).intValue();
      sYYYY=Integer.valueOf(startYYYY).intValue();
      eDD=Integer.valueOf(endDD).intValue();
      eMM=Integer.valueOf(endMM).intValue();
      eYYYY=Integer.valueOf(endYYYY).intValue();
   }catch(NumberFormatException e){
    
      out.write(" ");
      out.write("<h3> invalid date values ");
      out.write("</h3> ");

   }

   if((sDD>0)&&(sDD<32)&&(sMM<13)&&(sMM>0)&&(sYYYY<2050)&&(sYYYY>1980)){
    if((eDD>0)&&(eDD<32)&&(eMM<13)&&(eMM>0)&&(eYYYY<2050)&&(eYYYY>1980)){
       sYYYY-=1900; // java date format
       eYYYY-=1900;
       sMM-=1;
       eMM-=1;
       Timestamp startDate=new Timestamp(sYYYY,sMM,sDD,0,0,0,0);
       Timestamp endDate=new Timestamp(eYYYY,eMM,eDD,0,0,0,0);
  try{
      if(newPass.equals(confirmPass)){
         ResultSet testPosName=connector.executeQuery("SELECT pos_name FROM position WHERE pos_name='"+pos_name+"'");
         if(testPosName.next()){ 
      out.write("  ");
      out.write("<!-- make sure position name is selected once -->\r\n           ");
      out.write("<h2> hello there, this account already exists!\r\n                try another name");
      out.write("</h2>\r\n      ");
}else{  //position name is ok, test user name and passowrd
              ResultSet User_res=connector.executeQuery("SELECT username,password FROM users WHERE username='"+newUser+"' AND password='"+newPass+"'");
              if(User_res.next()){ 
      out.write("\r\n                  ");
      out.write("<H2> account already exists! ");
      out.write("<H2>\r\n            ");
}else{ // every thing is ok
                  if(allow_def!=null)
                    allow_def="yes";
                  else
                    allow_def="no";
                  connector.executeUpdate("INSERT INTO position (pos_name,can_define_new_path) VALUES('"+pos_name+"','"+allow_def+"')");
                  ResultSet pos_id_res=connector.executeQuery("SELECT pos_id FROM position WHERE pos_name='"+pos_name+"'");
                  if(pos_id_res.next()){
                    int pos_id=pos_id_res.getInt("pos_id");
                    connector.executeUpdate("INSERT INTO users (pos_id,username,password,startDate,endDate) VALUES ("+pos_id+",'"+newUser+"','"+newPass+"','"+startDate+"','"+endDate+"')");
                    // tell here ++++++++++++++++++++++++++++++
                 }
            
      out.write("\r\n                  ");
      out.write("<h2> a new account has been registered ");
      out.write("<h2>\r\n            ");
 }
        }

    }}
 catch(Exception e){ 
      out.write("\r\n    Error: ");
      out.print( e.getMessage() );
      out.write("\r\n ");
 }}
 else{
 
      out.write(" invalid  date ");

 }
 }else{
  
      out.write(" invalid  date ");

  }
      out.write("\r\n\r\n\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }
}
