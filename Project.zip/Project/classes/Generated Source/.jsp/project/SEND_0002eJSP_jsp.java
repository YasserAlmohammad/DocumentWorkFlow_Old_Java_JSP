import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;
import java.sql.*;
import java.util.StringTokenizer;

public class SEND_0002eJSP_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  static {
    _jspx_includes = new java.util.Vector(1);
    _jspx_includes.add("/ConnectInclude.jsp");
  }

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=windows-1256");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      project.Connect connector = null;
      synchronized (session) {
        connector = (project.Connect) pageContext.getAttribute("connector", PageContext.SESSION_SCOPE);
        if (connector == null){
          try {
            connector = (project.Connect) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.Connect");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.Connect", exc);
          }
          pageContext.setAttribute("connector", connector, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n");
      project.UserInfo userInfo = null;
      synchronized (application) {
        userInfo = (project.UserInfo) pageContext.getAttribute("userInfo", PageContext.APPLICATION_SCOPE);
        if (userInfo == null){
          try {
            userInfo = (project.UserInfo) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.UserInfo");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.UserInfo", exc);
          }
          pageContext.setAttribute("userInfo", userInfo, PageContext.APPLICATION_SCOPE);
        }
      }
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n\r\n");
      out.write("<meta name=\"GENERATOR\" content=\"Microsoft FrontPage 5.0\">\r\n");
      out.write("<meta name=\"ProgId\" content=\"FrontPage.Editor.Document\">\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1256\">\r\n\r\n");
      out.write("<title>\r\nsend\r\n");
      out.write("</title>\r\n");
      out.write("</head>\r\n");
      out.write("<body bgcolor=\"#eeeeee\">\r\n");
 if(userInfo.getPos_id()<0){ //any one can't use any page without signing in, he may see the forms, but can't use them
   
      out.write(" ");
      if (true) {
        pageContext.forward("error.htm");
        return;
      }
      out.write("\r\n");
} 
      out.write("\r\n\r\n\r\n");
      out.write("<!-- tell now we considerd the content as text file, later we may consider it as link to a local file\r\n     that we can upload it from user's machine to the server -->\r\n");

   String path_name=request.getParameter("path_val");
   String num_on_doc=request.getParameter("num_on_doc");
   String content=request.getParameter("content");
   String pos_id=request.getParameter("pos_name");
   String day=request.getParameter("day"), month=request.getParameter("month"), year=request.getParameter("year"),
   note=request.getParameter("note");

   int dd=0,mm=0,yyyy=0;
   try{ //check date format
      dd=Integer.valueOf(day).intValue();
      mm=Integer.valueOf(month).intValue();
      yyyy=Integer.valueOf(year).intValue();
   }
   catch(NumberFormatException e){
      
      out.write(" ");
      out.write("<h3> the date parameters are wrong, check it again");
      out.write("</h3> ");

   }

   //check date for value errors
   if(!((dd>0)&&(dd<32)&&(mm<13)&&(mm>0)&&(yyyy<2050)&&(yyyy>1980))){
      
      out.write("<h3> error: date is invalid ");
      out.write("</h3>");

   }else{ //continue
   yyyy=yyyy-1900;
   mm-=1; //month starts from 0 in Timestamp
   Timestamp date_on_doc=new Timestamp(yyyy,mm,dd,0,0,0,0);

   //we don't allow null values for : num_on_doc or date_on_doc, also you can't send empty message
   if((num_on_doc.equals(""))||(content.equals(""))||(path_name.equals("null"))){
      
      out.write(" ");
      out.write("<h3> some fields are missing, please check you request again ");
      out.write("</h3> ");

   }
   else{

   //if type== Manual then we must send the message to the selected position else to the one at the begining
   //of address_chain specified by path type
   try{
      //first save the document conetent
      //we may use transactions for the connection class if jdkID >= 1.4
      connector.executeUpdate("INSERT INTO document(num_on_doc,date_on_doc,content,pos_id,doc_type) VALUES ('"+num_on_doc+"','"+date_on_doc+"','"+content+"',"+userInfo.getPos_id()+",'"+path_name+"')");
      //now prepare the link info to be sent

      //then we get the subject " or the position description "
      ResultSet subject=connector.executeQuery("SELECT pos_name FROM position WHERE pos_id="+userInfo.getPos_id());
      String subj="";
      if(subject.next()){
          subj=subject.getString("pos_name");
          subject.close();
      }

      if(!((path_name.equals("manual"))&&(subj.equals("archive")))){ // when position==archive and doc_type==manul the message will be sent to save only
      //first get the doc_serial and date
      ResultSet doc_ids=connector.executeQuery("SELECT serial,date FROM document WHERE date=(SELECT MAX(date) FROM document WHERE pos_id="+userInfo.getPos_id()+")");
      String doc_serial="",doc_date="";
      if(doc_ids.next()){
        doc_serial=doc_ids.getString("serial");
        doc_date=doc_ids.getString("date");
      }


      //if type==Manual then we don't need to know the address chain
      if(path_name.equals("manual")){
          //send the link to pos identified by pos_name
          //address_chain in manual case = 0
          connector.executeUpdate("INSERT INTO inbox(belongs_to_pos,doc_serial,doc_date,currentAddressPos,address_chain,subject) VALUES ("+pos_id+","+doc_serial+",'"+doc_date+"',1,'"+userInfo.getPos_id()+"','"+subj+"')");

      }
      else{ //use address_chain info to get the next position
       ResultSet address_rs=connector.executeQuery("SELECT address_chain FROM path WHERE path_name='"+path_name+"'");
        if(address_rs.next()){
           String address=address_rs.getString("address_chain");
           StringTokenizer tokens=new StringTokenizer(address);
           tokens.nextToken();
           pos_id=tokens.nextToken();
           int current_address_pos=1;
           if(pos_id.equals(""+userInfo.getPos_id())){
              pos_id=tokens.nextToken();
              ++current_address_pos;
           }
           //sending a link to inbox
           connector.executeUpdate("INSERT INTO inbox(belongs_to_pos,doc_serial,doc_date,currentAddressPos,address_chain,subject) VALUES ("+pos_id+","+doc_serial+",'"+doc_date+"',"+current_address_pos+",'"+address+"','"+subj+"')");

        }
      }
      //now record this action in the history: FROM -----> TO record
      connector.executeUpdate("INSERT INTO History(to_pos,from_pos,doc_serial,doc_date,note) VALUES ("+pos_id+","+userInfo.getPos_id()+","+doc_serial+",'"+doc_date+"','"+note+"')");

      
      out.write("<h1>document was successfully sent");
      out.write("</h1> ");

     }}catch(SQLException e){
      out.write("\r\n        ");
      out.write("<h2> SQL error: ");
      out.write("</h2> ");
      out.print( e.toString() );
      out.write("\r\n  ");
 }
  }
 } 
      out.write("\r\n\r\n");
      out.write("<!-- we may add the first destination to the history, also we could ignore the first position in the address chain if it\r\n     was the same as the current signed in position -->\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }
}
