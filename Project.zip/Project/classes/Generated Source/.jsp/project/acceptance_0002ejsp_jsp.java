import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;
import java.sql.*;
import java.util.StringTokenizer;

public class acceptance_0002ejsp_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  static {
    _jspx_includes = new java.util.Vector(1);
    _jspx_includes.add("/ConnectInclude.jsp");
  }

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      project.Connect connector = null;
      synchronized (session) {
        connector = (project.Connect) pageContext.getAttribute("connector", PageContext.SESSION_SCOPE);
        if (connector == null){
          try {
            connector = (project.Connect) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.Connect");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.Connect", exc);
          }
          pageContext.setAttribute("connector", connector, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n");
      project.UserInfo userInfo = null;
      synchronized (application) {
        userInfo = (project.UserInfo) pageContext.getAttribute("userInfo", PageContext.APPLICATION_SCOPE);
        if (userInfo == null){
          try {
            userInfo = (project.UserInfo) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.UserInfo");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.UserInfo", exc);
          }
          pageContext.setAttribute("userInfo", userInfo, PageContext.APPLICATION_SCOPE);
        }
      }
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n\r\n");
      out.write("<meta name=\"GENERATOR\" content=\"Microsoft FrontPage 5.0\">\r\n");
      out.write("<meta name=\"ProgId\" content=\"FrontPage.Editor.Document\">\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">\r\n\r\n");
      out.write("<head>\r\n");
      out.write("<title>acceptance");
      out.write("</title>\r\n");
      out.write("</head>\r\n\r\n");
      out.write("<body bgcolor=\"#eeeeee\">\r\n\r\n");
 if(userInfo.getPos_id()<0){ //any one can't use any page without signing in, he may see the forms, but can't use them
   
      out.write(" ");
      if (true) {
        pageContext.forward("error.htm");
        return;
      }
      out.write("\r\n");
} 
      out.write("\r\n\r\n\r\n");
      out.write("<p align=\"center\">\r\n");
      out.write("<a href=\"inbox.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>inbox");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"outbox.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>outbox");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"sendPageGenerator.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>send doc");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"reporting.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>reporting");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"changeUserPass.jsp\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>changePassword");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>&nbsp;&nbsp;\r\n");
      out.write("<a href=\"helpFiles/help.htm\">");
      out.write("<font color=\"#000080\">");
      out.write("<b>help&amp;support");
      out.write("</b>");
      out.write("</font>");
      out.write("</a>");
      out.write("</p>\r\n");
      out.write("<form method=\"POST\" action=\"redirect.jsp\">\r\n  ");
      out.write("<p>\r\n  ");
 String doc_ids= request.getParameter("doc_ids");
     String content="",doc_serial="",doc_type="";
     Timestamp doc_date=null,arrive_date=null;
     String num_on_doc="",date_on_doc="";
    try{
    //we wrapped document identifiers in the request parameters
     StringTokenizer tokens=new StringTokenizer(doc_ids);
     if(tokens.hasMoreElements())
        doc_serial=tokens.nextToken("*"); // * was the separator between date and serial: date may has spaces
     if(tokens.hasMoreElements())
        doc_date=new Timestamp(Long.valueOf(tokens.nextToken("*")).longValue());
    if(tokens.hasMoreElements())
        arrive_date=new Timestamp(Long.valueOf(tokens.nextToken("*")).longValue());
     ResultSet r=connector.executeQuery("SELECT date,content,doc_type,num_on_doc,date_on_doc FROM document WHERE serial="+doc_serial);

     while(r.next()){
      Timestamp d=r.getTimestamp("date");
      //check date match in day,month,year
      if((d.getYear()==doc_date.getYear())&&(d.getMonth()==doc_date.getMonth())&&(d.getDay()==doc_date.getDay())){
        content=r.getString("content");
        doc_type=r.getString("doc_type");
        num_on_doc=r.getString("num_on_doc");
        date_on_doc=r.getString("date_on_doc");
      }
     }
      out.write("\r\n\r\n  ");
      out.write("<font color=\"#800000\">");
      out.write("<b>document numeber:");
      out.print(num_on_doc);
      out.write(" originated at:");
      out.print(date_on_doc);
      out.write("</b>");
      out.write("</font>\r\n  ");
      out.write("<textarea rows=\"20\" name=\"content\" cols=\"100\">");
      out.print( content );
      out.write("</textarea>");
      out.write("</p>\r\n  ");
      out.write("<p>&nbsp;the above text will not change, if you have a note write it bellow:\r\n  ");
      out.write("</p>\r\n  ");
      out.write("<p>");
      out.write("<textarea rows=\"4\" name=\"note\" cols=\"50\"> ");
      out.write("</textarea>");
      out.write("</p>\r\n  ");
      out.write("<p>");
      out.write("<select size=\"1\" name=\"choice\">\r\n  ");
      out.write("<!-- we could make serial as hidden field -->\r\n  ");
      out.write("<option selected value=\"ok\">ok");
      out.write("</option>\r\n  ");
      out.write("<option value=\"reject\">reject");
      out.write("</option>\r\n  ");
      out.write("</select>");
      out.write("</p>\r\n\r\n\r\n\r\n");

    if(doc_type.equals("manual")){
       // view all positions available for manual direcing
   
      out.write(" ");
      out.write("<h3>you must select destination position to send the message for ");
      out.write("</h3>\r\n      ");
      out.write("<select size=\"1\" name=\"pos_id\"> ");

       String pos_name="",pos_id;
       ResultSet pos=connector.executeQuery("SELECT pos_name,pos_id FROM position WHERE pos_name<> 'administrator' AND pos_id<>"+userInfo.getPos_id());
       while(pos.next()){
         pos_name=pos.getString("pos_name");
         pos_id=pos.getString("pos_id");
         //we can know everything about user from pos_id
         
      out.write("\r\n         ");
      out.write("<option value=\"");
      out.print( pos_id );
      out.write("\"> ");
      out.print(pos_name );
      out.write("</option>\r\n       ");
}
        
      out.write("   ");
      out.write("</select>");
      out.write("</p> ");


   }
  }catch(SQLException e){ 
      out.write("\r\n    ");
      out.write("<h1> SQL error ");
      out.write("<h1> ");
      out.print(e.toString() );
      out.write("\r\n");
 } 
      out.write("\r\n\r\n  ");
      out.write("<!-- ids for the link are passed between interactived pages-->\r\n  ");
      out.write("<input type=\"hidden\" name=\"doc_serial\" value=\"");
      out.print( doc_serial );
      out.write("\" >\r\n  ");
      out.write("<input type=\"hidden\" name=\"doc_date\" value=\"");
      out.print(doc_date.getTime());
      out.write("\" >\r\n  ");
      out.write("<input type=\"hidden\" name=\"arrive_date\" value=\"");
      out.print(arrive_date.getTime());
      out.write("\">\r\n   ");
      out.write("<h4>if you are the one who published this documnet and rejeted it, it will be deleted permanently\r\n  ");
      out.write("<br>you can check the document history to be sure of what happened before it reached you");
      out.write("</h4>\r\n  ");
      out.write("<p>");
      out.write("<input type=\"submit\" value=\"submit\" name=\"submit\">&nbsp;&nbsp; ");
      out.write("</p>\r\n");
      out.write("</form>\r\n\r\n");
      out.write("<hr>\r\n");
      out.write("<form method=\"POST\" action=\"showHistory.jsp\">\r\n  ");
      out.write("<input type=\"hidden\" name=\"doc_serial\" value=\"");
      out.print( doc_serial );
      out.write("\" >\r\n  ");
      out.write("<input type=\"hidden\" name=\"doc_date\" value=\"");
      out.print(doc_date.getTime());
      out.write("\" >\r\n  ");
      out.write("<input type=\"submit\" value=\"show this message history\">\r\n");
      out.write("</form>\r\n");
      out.write("<hr>\r\n");
      out.write("</body>\r\n\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }
}
