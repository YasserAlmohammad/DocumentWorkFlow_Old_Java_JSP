import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;
import java.sql.*;
import java.util.StringTokenizer;

public class UsersList_0002ejsp_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  static {
    _jspx_includes = new java.util.Vector(1);
    _jspx_includes.add("/ConnectInclude.jsp");
  }

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      project.Connect connector = null;
      synchronized (session) {
        connector = (project.Connect) pageContext.getAttribute("connector", PageContext.SESSION_SCOPE);
        if (connector == null){
          try {
            connector = (project.Connect) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.Connect");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.Connect", exc);
          }
          pageContext.setAttribute("connector", connector, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n");
      project.UserInfo userInfo = null;
      synchronized (application) {
        userInfo = (project.UserInfo) pageContext.getAttribute("userInfo", PageContext.APPLICATION_SCOPE);
        if (userInfo == null){
          try {
            userInfo = (project.UserInfo) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.UserInfo");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.UserInfo", exc);
          }
          pageContext.setAttribute("userInfo", userInfo, PageContext.APPLICATION_SCOPE);
        }
      }
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n\r\n");
      out.write("<meta name=\"GENERATOR\" content=\"Microsoft FrontPage 5.0\">\r\n");
      out.write("<meta name=\"ProgId\" content=\"FrontPage.Editor.Document\">\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1256\">\r\n\r\n");
      out.write("<title>\r\na list of the system users\r\n");
      out.write("</title>\r\n");
      out.write("</head>\r\n");
      out.write("<body bgcolor=\"#eeeeee\">\r\n\r\n");
 if(userInfo.getPos_id()<0){ //any one can't use any page without signing in, he may see the forms, but can't use them
   
      out.write(" ");
      if (true) {
        pageContext.forward("error.htm");
        return;
      }
      out.write("\r\n");
} 
      out.write("\r\n\r\n");
      out.write("<br>\r\n");
      out.write("<table border=\"2\" bordercolor=\"#808080\">\r\n  ");
      out.write("<tr>\r\n      ");
      out.write("<td> user name ");
      out.write("</td>\r\n      ");
      out.write("<td> account description ");
      out.write("</td>\r\n      ");
      out.write("<td> start valid at ");
      out.write("</td>\r\n      ");
      out.write("<td> end validation at ");
      out.write("</td>\r\n");
 ResultSet users=connector.executeQuery("SELECT count(pos_id) FROM users");
  int count=0,i=0;
  if(users.next()){ //get users count
    count=users.getInt(1);
  }

  users=connector.executeQuery("SELECT username,startDate,endDate,pos_id FROM users");
  String [][] u=new String[count][4]; //ResultSet is used only once, so we store value in
  //dynamic array then retore the vcalues
  while((users.next())&&(i<count)){
    u[i][0]=users.getString("username");
    u[i][1]=users.getString("startDate");
    u[i][2]=users.getString("endDate");
    u[i][3]=users.getString("pos_id");
    ++i;
  }

  i=0;
  while(i<count){
    String pos_id=u[i][3];
    users=connector.executeQuery("SELECT pos_name FROM position WHERE pos_id="+pos_id);
    if(users.next()){
       
      out.write(" ");
      out.write("<tr>\r\n          ");
      out.write("<td> ");
      out.print( u[i][0] );
      out.write(" ");
      out.write("</td>\r\n          ");
      out.write("<td> ");
      out.print( users.getString("pos_name") );
      out.write(" ");
      out.write("</td>\r\n          ");
      out.write("<td> ");
      out.print( u[i][1] );
      out.write(" ");
      out.write("</td>\r\n          ");
      out.write("<td> ");
      out.print( u[i][2] );
      out.write(" ");
      out.write("</td>\r\n       ");
      out.write("</tr>\r\n      ");

    }
    ++i;

  }

  /*
  while(users.next()){
    
      out.write(" ");
      out.write("<tr>\r\n          ");
      out.write("<td> ");
      out.print( users.getString("username") );
      out.write(" ");
      out.write("</td>\r\n          ");
      out.write("<td> ");
      out.print( users.getString("startDate") );
      out.write(" ");
      out.write("</td>\r\n          ");
      out.write("<td> ");
      out.print( users.getString("endDate") );
      out.write(" ");
      out.write("</td>\r\n       ");
      out.write("</tr>\r\n    ");

  }
  */

      out.write("\r\n");
      out.write("</table>\r\n\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }
}
