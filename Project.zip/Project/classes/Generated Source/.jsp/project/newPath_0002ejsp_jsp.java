import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;
import java.sql.*;
import java.util.StringTokenizer;

public class newPath_0002ejsp_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  static {
    _jspx_includes = new java.util.Vector(1);
    _jspx_includes.add("/ConnectInclude.jsp");
  }

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      project.Connect connector = null;
      synchronized (session) {
        connector = (project.Connect) pageContext.getAttribute("connector", PageContext.SESSION_SCOPE);
        if (connector == null){
          try {
            connector = (project.Connect) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.Connect");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.Connect", exc);
          }
          pageContext.setAttribute("connector", connector, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n");
      project.UserInfo userInfo = null;
      synchronized (application) {
        userInfo = (project.UserInfo) pageContext.getAttribute("userInfo", PageContext.APPLICATION_SCOPE);
        if (userInfo == null){
          try {
            userInfo = (project.UserInfo) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "project.UserInfo");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "project.UserInfo", exc);
          }
          pageContext.setAttribute("userInfo", userInfo, PageContext.APPLICATION_SCOPE);
        }
      }
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n\r\n");
      out.write("<head>\r\n\r\n");
      out.write("<meta name=\"GENERATOR\" content=\"Microsoft FrontPage 5.0\">\r\n");
      out.write("<meta name=\"ProgId\" content=\"FrontPage.Editor.Document\">\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">\r\n\r\n");
      out.write("<title>new document type generator");
      out.write("</title>\r\n");
      out.write("</head>\r\n\r\n");
      out.write("<SCRIPT language=\"javaScript\" >\r\n\r\nvar content=\"\";\r\nvar oldPos=\"\";\r\nvar newPos=\"\";\r\nfunction addclick(){\r\n\tcontent=document.newPath.address_chain.value\r\n        newPos=document.newPath.positions.options[document.newPath.positions.selectedIndex].value\r\n        if(oldPos==newPos){ // we'll prevent user from sending letter to him self directly\r\n          alert(\"can't send to your self directly\")\r\n        }\r\n        else{  //it's ok\r\n          // we can parse the address before it's sent to createPath.jsp - for arabic to work -\r\n\r\n          if(content==\"\"){\r\n\t    document.newPath.address_chain.value=newPos\r\n          }\r\n          else{\r\n            document.newPath.address_chain.value=content+\"*\"+newPos\r\n          }\r\n            oldPos=newPos\r\n\r\n        }\r\n\r\n        content=document.newPath.address_chain.value\r\n\r\n        /*\r\n        without checking\r\n        content=document.newPath.address_chain.value\r\n\tdocument.newPath.address_chain.value=content+\">\"+document.newPath.positions.options[document.newPath.positions.selectedIndex].value\r\n");
      out.write("        content=document.newPath.address_chain.value\r\n        */\r\n}\r\n\r\nfunction contentChange(){\r\n    document.newPath.address_chain.value=content;\r\n    alert(\"what are you doing? you musn't change this content manually, use reset button to restart building the path\")\r\n}\r\n\r\nfunction loadEvent(){\r\n  oldPos=document.newPath.address_chain.value\r\n}\r\n\r\n");
      out.write("</SCRIPT>\r\n\r\n");
      out.write("<body bgcolor=\"#eeeeee\" onLoad=\"loadEvent()\">\r\n\r\n");
 if(userInfo.getPos_id()<0){ //any one can't use any page without signing in, he may see the forms, but can't use them
   
      out.write(" ");
      if (true) {
        pageContext.forward("error.htm");
        return;
      }
      out.write("\r\n");
}
  try{
 //first check if our friend can define paths or not
  ResultSet r=connector.executeQuery("SELECT can_define_new_path FROM position WHERE pos_id="+userInfo.getPos_id());
  if(r.next()){
    String can=r.getString(1);
    if(can.equals("yes")){ //ok you can

      out.write("\r\n\r\n");
      out.write("<form name=\"newPath\" method=\"POST\" action=\"createPath.jsp\">\r\n  ");
      out.write("<p>name document type:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n  ");
      out.write("<input type=\"text\" name=\"path_name\" size=\"28\">");
      out.write("</p>\r\n  ");
      out.write("<p>\r\n  ");
      out.write("<input type=\"button\" value=\"add selected direction\" name=\"add\" onclick=\"addclick()\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n  ");
      out.write("<select size=\"1\" name=\"positions\">\r\n");

   ResultSet pos_names=connector.executeQuery("SELECT pos_name,pos_id FROM position WHERE pos_name<>'administrator' AND pos_name<>'archive'");
   String name="";
   //add the first positionas selected
   if(pos_names.next()){
      name=pos_names.getString("pos_name");
      
      out.write("\r\n      ");
      out.write("<option value=\"");
      out.print( name );
      out.write("\" selected>");
      out.print( name );
      out.write(" ");
      out.write("</option>\r\n   ");

   }
  //add all positions available
   while(pos_names.next()){
      name=pos_names.getString("pos_name");
      out.write("\r\n      ");
      out.write("<option value=\"");
      out.print( name );
      out.write("\" > ");
      out.print( name );
      out.write(" ");
      out.write("</option>\r\n  ");

   }

      out.write("\r\n  ");
      out.write("<!-- we could add check restriction to assure that any position won't put itself in th beginning of path -->\r\n  ");
      out.write("</select> don't put yourself as the beginner of the path, you will be automatically considerd ");
      out.write("</p>\r\n  ");
 r=connector.executeQuery("SELECT pos_name FROM position WHERE pos_id="+userInfo.getPos_id());
     String current_pos_name="";
     if(r.next()){
        current_pos_name=r.getString("pos_name");
     }
   r=connector.executeQuery("SELECT username FROM users WHERE pos_id="+userInfo.getPos_id());
   if(r.next()){
    String username=r.getString("username");
    if("admin".equals(username.toLowerCase())){ //allow admin to define paths for others
      
      out.write("\r\n      ");
      out.write("<p>");
      out.write("<textarea rows=\"4\" name=\"address_chain\" cols=\"100\" onChange=\"contentChange()\">");
      out.write("</textarea>");
      out.write("</p>\r\n  ");
}else{
  
      out.write("\r\n  ");
      out.write("<p>");
      out.write("<textarea rows=\"4\" name=\"address_chain\" cols=\"100\" onChange=\"contentChange()\">");
      out.print(current_pos_name );
      out.write(" ");
      out.write("</textarea>");
      out.write("</p>\r\n  ");
}
  }
      out.write("\r\n  ");
      out.write("<p>input template if you like");
      out.write("<br> ");
      out.write("<textarea rows=\"8\" name=\"template\" cols=\"100\">");
      out.write("</textarea>");
      out.write("</p>\r\n  ");
      out.write("<p>&nbsp;");
      out.write("</p>\r\n  ");
      out.write("<p>");
      out.write("<input type=\"submit\" value=\"create path\" name=\"B1\">\r\n  ");
      out.write("<input type=\"reset\" value=\"Reset\" name=\"B2\">");
      out.write("</p>\r\n\r\n");
      out.write("</form>\r\n\r\n");
 }else{ //you can't define new path
    
      out.write("  ");
      out.write("<h3> you can't define new document type, contact administrator for more information\r\n    ");

  }}
  }catch(SQLException e){ 
      out.write(" ");
      out.write("<h3> ERROR ");
      out.write("</H3> ");
 }
      out.write("\r\n\r\n");
      out.write("</body>\r\n\r\n");
      out.write("</html>");
    } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }
}
